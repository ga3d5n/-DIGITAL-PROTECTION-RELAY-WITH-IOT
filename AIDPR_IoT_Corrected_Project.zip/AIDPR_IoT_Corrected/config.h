#pragma once
#include <Arduino.h>

// ESP32-WROOM-32 pin map
namespace Pins {
  constexpr uint8_t ZMPT_ADC = 34;       // ADC1 input-only
  constexpr uint8_t ACS_ADC = 35;        // Reserved; ACS712 is not used by firmware

  constexpr uint8_t OLED_SDA = 21;
  constexpr uint8_t OLED_SCL = 22;

  constexpr uint8_t RELAY = 26;
  constexpr uint8_t BUZZER = 27;

  constexpr uint8_t LED_GREEN = 18;
  constexpr uint8_t LED_YELLOW = 19;
  constexpr uint8_t LED_RED = 23;

  constexpr uint8_t BUTTON_RESET = 13;   // Button to GND, INPUT_PULLUP
  constexpr uint8_t BUTTON_TEST = 14;    // Button to GND, INPUT_PULLUP
}

namespace Config {
  constexpr uint8_t OLED_ADDRESS = 0x3C;
  constexpr uint16_t OLED_WIDTH = 128;
  constexpr uint16_t OLED_HEIGHT = 64;

  constexpr bool RELAY_ACTIVE_LOW = true; // Verify with low-voltage test

  constexpr float DEFAULT_OC_A = 1.5f;
  constexpr float DEFAULT_UC_A = 0.2f;
  constexpr float DEFAULT_OV_V = 250.0f;
  constexpr float DEFAULT_UV_V = 180.0f;

  constexpr uint32_t DEFAULT_TRIP_DELAY_MS = 2000;
  constexpr float VOLTAGE_HYSTERESIS_V = 5.0f;
  constexpr float CURRENT_HYSTERESIS_A = 0.1f;

  constexpr uint32_t SENSOR_SAMPLE_WINDOW_MS = 250;
  constexpr uint32_t TELEMETRY_INTERVAL_MS = 1000;
  constexpr uint32_t BUTTON_DEBOUNCE_MS = 40;

  // Retained for reference only. ACS712 is not read by the active firmware.
  constexpr float ACS712_SENSITIVITY_V_PER_A = 0.066f;
  constexpr float ADC_DIVIDER_RATIO = 1.6667f; // 10k top / 15k bottom

  // Existing ZMPT101B calibration supplied by the user. Do not alter.
  constexpr float ZMPT_VOLTS_PER_SENSOR_VOLT = 212.88f;

  constexpr float ADC_REFERENCE_V = 3.3f;
  constexpr uint16_t ADC_MAX = 4095;

  constexpr float ADAPTIVE_MIN_FACTOR = 0.90f;
  constexpr float ADAPTIVE_MAX_FACTOR = 1.00f;
  constexpr float ADAPTIVE_STEP = 0.01f;
  constexpr float PREDICTIVE_WARNING_FRACTION = 0.90f;

  // Retained as a legacy setting; demo input no longer expires by timeout.
  constexpr uint32_t SIMULATED_INPUT_TIMEOUT_MS = 30000;
}
