#pragma once
// Local AP credentials. Change before demonstration.
// Use at least 8 characters for WPA2.
#define AIDPR_AP_SSID "AIDPR-IoT"
#define AIDPR_AP_PASSWORD "aidpr1234"
