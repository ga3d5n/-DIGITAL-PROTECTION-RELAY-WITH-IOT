# AIDPR-IoT Corrected ESP32 Project

## Included corrections
- Simulated current is stored in ESP32 Preferences and restored after restart. The dashboard saves it automatically whenever the slider is changed.
- The permanent-trip reset bug is corrected: a trip remains latched, while the firmware continues checking whether automatic fault conditions have cleared.
- Manual Trip is available on the web dashboard. Turning it OFF does not reset the trip; use Reset after manual trip is OFF and automatic faults have cleared.
- ACS712 average raw ADC count and an experimental RMS-current estimate are displayed only. ACS712 data is not passed into protection logic and cannot trip the relay.
- OLED and web dashboard show voltage, simulated current, OC/UC limits, state, relay output and ACS712 diagnostics.
- Relay output is enabled only in HEALTHY/WARNING states and disabled in TRIPPED/SENSOR_ERROR states.
- Existing `src/sensors/voltage_sensor.cpp` and `config.h` ZMPT calibration constant (`212.88f`) are preserved from the uploaded project.

## Arduino IDE setup
1. Extract this ZIP.
2. Open `AIDPR_IoT_Corrected.ino` from the `AIDPR_IoT_Corrected` folder.
3. Select **ESP32 Dev Module** (ESP32-WROOM-32) and the correct COM port.
4. Install the libraries **Adafruit GFX Library** and **Adafruit SSD1306**. The ESP32 Arduino core provides WiFi, WebServer and Preferences.
5. Upload. Connect your phone/laptop to the ESP32 access point and open `http://192.168.4.1`.

Default AP credentials are in `secrets.h`. Change them before any public demonstration.

## Important operating notes
- Current protection uses the dashboard's SOFTWARE SIMULATED CURRENT only. It is not a measured load-current protection function.
- ACS712 values are experimental and for display only; they are not calibrated or safety-rated.
- The voltage measurement code and calibration were preserved, but any mains-connected sensor module still requires safe enclosure, isolation, fuse protection, adequate creepage/clearance and inspection by a qualified electrician.
- Do not connect the 230 V fan/load until a qualified electrician has verified the relay module, contact ratings, wiring, enclosure and fail-safe behaviour. Test the firmware and relay control with low-voltage loads first. Never use a breadboard for mains wiring.
- Confirm relay board active-low polarity (`RELAY_ACTIVE_LOW`) with a low-voltage test before connecting any mains load.
- The relay closes the load path only in HEALTHY/WARNING. A sensor error or trip disables the relay output.
- The ACS712 ADC input must remain within the ESP32's 0–3.3 V range. ESP32 GPIOs are not 5 V tolerant.

## Persistence
The simulator value is stored in Preferences namespace `aidpr`, key `demoA`. It is saved automatically when `/api/current` is updated and loaded during startup. OC/UC/adaptive settings remain in the same Preferences namespace.
