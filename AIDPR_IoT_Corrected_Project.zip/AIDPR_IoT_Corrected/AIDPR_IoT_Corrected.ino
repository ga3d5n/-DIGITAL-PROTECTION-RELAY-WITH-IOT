#include <Arduino.h>
#include "config.h"
#include "src/sensors/voltage_sensor.h"
#include "src/sensors/current_sensor.h"
#include "src/simulation/current_simulator.h"
#include "src/protection/protection.h"
#include "src/protection/adaptive.h"
#include "src/output/relay.h"
#include "src/output/indicators.h"
#include "src/output/buzzer.h"
#include "src/display/oled.h"
#include "src/communication/web_server.h"
#include "src/storage/settings.h"
#include "src/storage/fault_logger.h"

VoltageSensor voltageSensor;
CurrentSensor currentSensor;
CurrentSimulator simulator;
Protection protection;
AdaptiveProtection adaptive;
RelayOutput relay;
Indicators indicators;
Buzzer buzzer;
OledDisplay oled;
LocalWebServer web;
SettingsStore settingsStore;
FaultLogger faultLog;
ProtectionSettings settings;
CurrentReading acsReading;

float voltageRms=0.0f;
bool voltageValid=false, oledOK=false;
float effectiveOc=Config::DEFAULT_OC_A, effectiveUc=Config::DEFAULT_UC_A;
uint32_t lastSensor=0, lastDisplay=0;
bool resetWasPressed=false, tripWasLogged=false;

void applyOutputs() {
  const SystemState state=protection.state();
  const bool permitLoad=(state==SystemState::HEALTHY || state==SystemState::WARNING);
  relay.setLoad(permitLoad);
  buzzer.set(state==SystemState::TRIPPED || state==SystemState::SENSOR_ERROR);
  indicators.update(state==SystemState::HEALTHY,
                    state==SystemState::WARNING,
                    state==SystemState::TRIPPED || state==SystemState::SENSOR_ERROR);
  if (state==SystemState::TRIPPED && !tripWasLogged) {
    faultLog.log(protection.faults(),voltageRms,simulator.value());
    tripWasLogged=true;
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(Pins::BUTTON_RESET,INPUT_PULLUP);
  pinMode(Pins::BUTTON_TEST,INPUT_PULLUP);
  pinMode(Pins::BUZZER,OUTPUT);
  relay.begin(Pins::RELAY,Config::RELAY_ACTIVE_LOW);
  indicators.begin(Pins::LED_GREEN,Pins::LED_YELLOW,Pins::LED_RED);
  buzzer.begin(Pins::BUZZER);
  relay.setLoad(false);

  analogReadResolution(12);
  analogSetPinAttenuation(Pins::ZMPT_ADC,ADC_11db);
  analogSetPinAttenuation(Pins::ACS_ADC,ADC_11db);

  // Existing ZMPT101B sensor code and calibration are deliberately unchanged.
  voltageSensor.begin(Pins::ZMPT_ADC);
  currentSensor.begin(Pins::ACS_ADC); // Display/diagnostic only; never used for protection.

  oledOK=oled.begin();
  settingsStore.begin();
  settings=settingsStore.load();
  simulator.set(settingsStore.loadDemoCurrent()); // Restore saved demo current after reboot.
  protection.begin();
  protection.setSettings(settings);
  faultLog.begin();
  web.begin(&settings,&simulator,&faultLog,&settingsStore,&protection);
  web.updateTelemetry(voltageRms,voltageValid,protection,relay.loadEnabled(),
                      acsReading,effectiveOc,effectiveUc);

  Serial.println("AIDPR-IoT AP started. Open http://192.168.4.1");
  Serial.println("OC/UC protection current source: SOFTWARE SIMULATION ONLY.");
  Serial.println("ACS712: display-only experimental data; excluded from protection.");
}

void loop() {
  web.handle();

  // A manual trip request acts immediately in the main loop. Turning it OFF
  // does not clear the latched trip; only Reset can do that.
  if (web.manualTripActive()) protection.trip(FAULT_MANUAL);

  if (millis()-lastSensor>=Config::SENSOR_SAMPLE_WINDOW_MS) {
    lastSensor=millis();
    VoltageReading vr=voltageSensor.readRms(200);
    voltageRms=vr.rmsVolts;
    voltageValid=vr.valid;

    // ACS712 reading is strictly telemetry/display-only.
    acsReading=currentSensor.readRms(100);

    const float demoCurrent=simulator.value();
    const bool demoValid=simulator.valid();
    ProtectionSettings effective=settings;
    effectiveOc=adaptive.updateOc(settings.oc,demoCurrent,settings.adaptive);
    effectiveUc=adaptive.updateUc(settings.uc,demoCurrent,settings.adaptive);
    effective.oc=effectiveOc;
    effective.uc=effectiveUc;
    protection.setSettings(effective);
    protection.evaluate(voltageRms,voltageValid,demoCurrent,demoValid);
    if (web.manualTripActive()) protection.trip(FAULT_MANUAL);

    applyOutputs();
    web.updateTelemetry(voltageRms,voltageValid,protection,relay.loadEnabled(),
                        acsReading,effectiveOc,effectiveUc);
  }

  if (digitalRead(Pins::BUTTON_RESET)==LOW && !resetWasPressed) {
    resetWasPressed=true;
    if (!web.manualTripActive() && protection.reset()) tripWasLogged=false;
  }
  if (digitalRead(Pins::BUTTON_RESET)==HIGH) resetWasPressed=false;

  // Re-apply outputs every pass so a web manual trip drops the relay promptly.
  applyOutputs();
  if (millis()-lastDisplay>500) {
    lastDisplay=millis();
    if (oledOK) oled.update(voltageRms,voltageValid,simulator.value(),settings,
                            protection,acsReading);
  }
}
