#include "current_simulator.h"
// Intentionally small translation unit; simulator is header-defined.
