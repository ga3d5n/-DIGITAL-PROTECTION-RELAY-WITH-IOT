#pragma once
#include <Arduino.h>

// Software-only demonstration input. It is NOT a physical current measurement.
class CurrentSimulator {
public:
  void set(float amps) {
    _amps = constrain(amps, 0.0f, 5.0f);
    _valid = true;
  }
  float value() const { return _amps; }
  bool valid() const { return _valid; }
  void invalidate() { _valid = false; }
private:
  float _amps = 1.0f; // Replaced at startup by the saved Preferences value.
  bool _valid = true;
};
