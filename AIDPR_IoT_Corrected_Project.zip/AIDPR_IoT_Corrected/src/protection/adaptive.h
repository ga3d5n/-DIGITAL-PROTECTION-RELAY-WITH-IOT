#pragma once
#include <Arduino.h>
class AdaptiveProtection {
public:
  float updateOc(float userLimit, float measuredCurrent, bool enabled);
  float updateUc(float userLimit, float measuredCurrent, bool enabled);
private:
  float _ocFactor=1.0f, _ucFactor=1.0f;
};
