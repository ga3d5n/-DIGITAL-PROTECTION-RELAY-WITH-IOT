#pragma once
#include <Arduino.h>

enum class SystemState { STARTUP, HEALTHY, WARNING, TRIPPED, SENSOR_ERROR };
enum FaultBits : uint8_t {
  FAULT_NONE = 0, FAULT_OV = 1, FAULT_UV = 2, FAULT_OC = 4,
  FAULT_UC = 8, FAULT_INPUT = 16, FAULT_MANUAL = 32
};

struct ProtectionSettings {
  float oc = 1.5f, uc = 0.2f, ov = 250.0f, uv = 180.0f;
  uint32_t delayMs = 2000;
  bool adaptive = true;
};

class Protection {
public:
  void begin();
  void setSettings(const ProtectionSettings& s) { _settings = s; }
  void evaluate(float voltage, bool voltageValid, float simulatedCurrent, bool simulatedValid);
  bool resetAllowed() const;
  bool reset();
  void trip(uint8_t faults);
  SystemState state() const { return _state; }
  uint8_t faults() const { return _faults; }
  const ProtectionSettings& settings() const { return _settings; }
  bool warning() const { return _warning; }
private:
  ProtectionSettings _settings;
  SystemState _state = SystemState::STARTUP;
  uint8_t _faults = FAULT_NONE;
  uint8_t _pending = FAULT_NONE;
  bool _warning = false;
  uint32_t _faultSince = 0;
};
