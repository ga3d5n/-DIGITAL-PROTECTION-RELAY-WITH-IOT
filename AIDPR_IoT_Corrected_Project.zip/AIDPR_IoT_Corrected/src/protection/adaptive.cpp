#include "adaptive.h"
#include "../../config.h"
float AdaptiveProtection::updateOc(float limit,float current,bool enabled){
  // Conservative bounded demonstration: tighten OC pickup slightly as current
  // approaches the user limit. Never raises the OC threshold above user setting.
  if(!enabled || limit<=0) {_ocFactor=1.0f;return limit;}
  float target=(current>limit*0.80f)?max(Config::ADAPTIVE_MIN_FACTOR,_ocFactor-Config::ADAPTIVE_STEP)
                                      :min(1.0f,_ocFactor+Config::ADAPTIVE_STEP);
  _ocFactor=constrain(target,Config::ADAPTIVE_MIN_FACTOR,Config::ADAPTIVE_MAX_FACTOR);
  return limit*_ocFactor;
}
float AdaptiveProtection::updateUc(float limit,float current,bool enabled){
  // Conservative bounded demonstration: move UC threshold downward by at most
  // 10% only when current is close to the lower threshold; never increase it.
  if(!enabled || limit<=0) {_ucFactor=1.0f;return limit;}
  if(current<limit*1.2f) _ucFactor=max(Config::ADAPTIVE_MIN_FACTOR,_ucFactor-Config::ADAPTIVE_STEP);
  else _ucFactor=min(1.0f,_ucFactor+Config::ADAPTIVE_STEP);
  return limit*_ucFactor;
}
