#pragma once
#include <Arduino.h>
class Predictor {
public:
  bool voltageApproaching(float v,float limit) const { return limit>0 && v>limit*0.90f; }
  bool currentApproaching(float i,float limit) const { return limit>0 && i>limit*0.90f; }
};
