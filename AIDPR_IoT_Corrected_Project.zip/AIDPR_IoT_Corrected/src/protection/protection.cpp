#include "protection.h"
#include "../../config.h"

void Protection::begin() {
  _state = SystemState::STARTUP;
  _faults = FAULT_NONE;
  _pending = FAULT_NONE;
  _warning = false;
  _faultSince = 0;
}

void Protection::evaluate(float voltage, bool voltageValid,
                          float simulatedCurrent, bool simulatedValid) {
  // Invalid protection inputs prevent reset, including while a trip is latched.
  if (!voltageValid || !simulatedValid) {
    _pending = FAULT_INPUT;
    _faultSince = millis();
    if (_state != SystemState::TRIPPED) _state = SystemState::SENSOR_ERROR;
    _warning = false;
    return;
  }

  uint8_t activeFaults = FAULT_NONE;
  if (voltage > _settings.ov) activeFaults |= FAULT_OV;
  if (voltage < _settings.uv) activeFaults |= FAULT_UV;
  if (simulatedCurrent > _settings.oc) activeFaults |= FAULT_OC;
  if (simulatedCurrent < _settings.uc) activeFaults |= FAULT_UC;

  _warning = (voltage > _settings.ov * Config::PREDICTIVE_WARNING_FRACTION) ||
             (simulatedCurrent > _settings.oc * Config::PREDICTIVE_WARNING_FRACTION);

  // A trip stays latched, but current conditions are still evaluated so Reset
  // becomes available only after every automatic fault has cleared.
  if (_state == SystemState::TRIPPED) {
    _pending = activeFaults;
    return;
  }

  if (activeFaults == FAULT_NONE) {
    _pending = FAULT_NONE;
    _faultSince = 0;
    _state = _warning ? SystemState::WARNING : SystemState::HEALTHY;
    return;
  }

  if (_pending != activeFaults) {
    _pending = activeFaults;
    _faultSince = millis();
  }
  if (millis() - _faultSince >= _settings.delayMs) trip(activeFaults);
}

void Protection::trip(uint8_t faults) {
  _faults |= faults;
  _state = SystemState::TRIPPED;
}

bool Protection::resetAllowed() const {
  return _state == SystemState::TRIPPED && _pending == FAULT_NONE;
}

bool Protection::reset() {
  if (!resetAllowed()) return false;
  _faults = FAULT_NONE;
  _pending = FAULT_NONE;
  _state = SystemState::HEALTHY;
  _warning = false;
  _faultSince = 0;
  return true;
}
