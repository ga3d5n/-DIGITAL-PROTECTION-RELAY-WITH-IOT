#pragma once
#include <Arduino.h>
class FaultLogger {public:void begin();void log(uint8_t faults,float volts,float demoA);String last()const{return _last;}private:String _last="No faults recorded";};
