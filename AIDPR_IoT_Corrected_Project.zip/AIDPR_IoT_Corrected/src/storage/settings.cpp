#include "settings.h"
#include <Preferences.h>
#include "../../config.h"

static Preferences p;

void SettingsStore::begin() { p.begin("aidpr", false); }

ProtectionSettings SettingsStore::load() {
  ProtectionSettings s;
  s.oc = p.getFloat("oc", Config::DEFAULT_OC_A);
  s.uc = p.getFloat("uc", Config::DEFAULT_UC_A);
  s.ov = p.getFloat("ov", Config::DEFAULT_OV_V);
  s.uv = p.getFloat("uv", Config::DEFAULT_UV_V);
  s.delayMs = p.getUInt("delay", Config::DEFAULT_TRIP_DELAY_MS);
  s.adaptive = p.getBool("adaptive", true);
  return s;
}

void SettingsStore::save(const ProtectionSettings& s) {
  p.putFloat("oc", s.oc);
  p.putFloat("uc", s.uc);
  p.putFloat("ov", s.ov);
  p.putFloat("uv", s.uv);
  p.putUInt("delay", s.delayMs);
  p.putBool("adaptive", s.adaptive);
}

float SettingsStore::loadDemoCurrent() {
  float value = p.getFloat("demoA", 1.0f);
  if (!isfinite(value) || value < 0.0f || value > 5.0f) value = 1.0f;
  return value;
}

void SettingsStore::saveDemoCurrent(float amps) {
  if (!isfinite(amps)) return;
  p.putFloat("demoA", constrain(amps, 0.0f, 5.0f));
}
