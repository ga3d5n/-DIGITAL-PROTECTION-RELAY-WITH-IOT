#pragma once
#include "../protection/protection.h"
class SettingsStore {
public:
  void begin();
  ProtectionSettings load();
  void save(const ProtectionSettings& s);
  float loadDemoCurrent();
  void saveDemoCurrent(float amps);
};
