#include "fault_logger.h"
#include <Preferences.h>
static Preferences fp;
void FaultLogger::begin(){fp.begin("aidprlog",false);_last=fp.getString("last","No faults recorded");}
void FaultLogger::log(uint8_t f,float v,float i){
 _last="Fault bits "+String(f)+" | "+String(v,1)+" V | demo "+String(i,2)+" A";
 fp.putString("last",_last);
}
