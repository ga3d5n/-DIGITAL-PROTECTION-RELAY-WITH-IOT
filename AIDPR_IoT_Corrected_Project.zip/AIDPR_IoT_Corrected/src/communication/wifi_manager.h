#pragma once
#include <Arduino.h>
class WifiManager {public:void begin();String ip()const;};
