#include "wifi_manager.h"
#include <WiFi.h>
#include "../../secrets.h"
void WifiManager::begin(){WiFi.mode(WIFI_AP);WiFi.softAP(AIDPR_AP_SSID,AIDPR_AP_PASSWORD);}
String WifiManager::ip()const{return WiFi.softAPIP().toString();}
