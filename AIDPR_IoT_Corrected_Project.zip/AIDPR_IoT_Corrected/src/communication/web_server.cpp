#include "web_server.h"
#include "../../secrets.h"
#include <WiFi.h>

static const char PAGE[] PROGMEM = R"HTML(
<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#0b1220"><title>AIDPR-IoT</title>
<style>
*{box-sizing:border-box}body{margin:0;padding:16px;background:#0b1220;color:#edf3fb;font-family:Arial,sans-serif}main{max-width:680px;margin:auto}section{background:#151f31;border:1px solid #2b3a52;border-radius:14px;padding:16px;margin:12px 0}h1{margin-bottom:4px}h2{margin:0 0 12px;font-size:17px}input[type=range]{width:100%;accent-color:#38bdf8}button{width:100%;padding:13px;border:0;border-radius:9px;background:#2563eb;color:white;font-weight:bold;margin-top:8px}.danger{background:#b91c1c}.secondary{background:#475569}.value{font-size:22px;font-weight:bold;float:right}.muted{color:#9aa9bd;font-size:12px;line-height:1.5}.status{line-height:1.8;overflow-wrap:anywhere}.grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}.tile{background:#0e1726;padding:12px;border-radius:10px}.tile b{display:block;font-size:19px;margin-top:5px}.switch{display:flex;align-items:center;gap:10px}.switch input{width:22px;height:22px}
</style></head><body><main><h1>AIDPR-IoT</h1><p class="muted">ESP32 LOCAL PROTECTION DEMONSTRATION</p>
<section><h2>Live measurements</h2><div class="grid"><div class="tile">Measured voltage<b id="v">--</b></div><div class="tile">Simulated current<b id="demoNow">--</b></div><div class="tile">ACS712 raw ADC<b id="raw">--</b></div><div class="tile">ACS712 estimated current<b id="acs">--</b></div><div class="tile">Relay output<b id="relay">--</b></div><div class="tile">System state<b id="state">--</b></div></div><p class="muted">ACS712 values are experimental display-only readings. They are NOT used for OC/UC protection. Simulated current is the only current input used by this demonstration's protection logic.</p></section>
<section><h2>Protection limits</h2><label>Overcurrent (OC) <span class="value" id="ocv">1.5 A</span></label><input id="oc" type="range" min="0.1" max="5" step="0.1" value="1.5"><p class="muted">0.1–5.0 A</p><label>Undercurrent (UC) <span class="value" id="ucv">0.2 A</span></label><input id="uc" type="range" min="0" max="2" step="0.1" value="0.2"><p class="muted">0.0–2.0 A</p><label class="switch"><input id="ad" type="checkbox" checked> Enable adaptive thresholds</label><p class="muted">Adaptive thresholds may adjust the effective OC/UC pickup within the configured bounds.</p><p class="muted" id="effective">Effective limits: --</p></section>
<section><h2>Simulated current input <span class="value" id="iv">1.0 A</span></h2><input id="i" type="range" min="0" max="5" step="0.1" value="1"><p class="muted">DEMO INPUT ONLY. This value is saved automatically to ESP32 Preferences and restored after restart.</p></section>
<section><h2>Manual protection</h2><label class="switch"><input id="manual" type="checkbox"> MANUAL TRIP (immediate)</label><p class="muted">Switching this OFF does not reset the trip. Press RESET after manual trip is OFF and all automatic faults have cleared.</p><button class="danger" onclick="setManual(true)">TRIP NOW</button><button class="secondary" onclick="resetSystem()">RESET PROTECTION</button><p id="manualMsg" class="muted"></p></section>
<section><h2>System status</h2><div id="status" class="status">Connecting...</div><p id="last" class="muted"></p></section>
<section><button onclick="saveSettings()">SAVE PROTECTION SETTINGS</button><p id="msg" class="muted"></p></section>
<p class="muted">Connect to AIDPR-IoT Wi-Fi and open http://192.168.4.1. Do not connect a mains load until relay wiring and enclosure have been inspected by a qualified electrician.</p></main>
<script>
const $=id=>document.getElementById(id);let settingsChanged=false,editing=false,manualRequest=false;
function draw(){ $('ocv').textContent=(+$('oc').value).toFixed(1)+' A';$('ucv').textContent=(+$('uc').value).toFixed(1)+' A';$('iv').textContent=(+$('i').value).toFixed(1)+' A'; }
['oc','uc'].forEach(id=>{$(id).addEventListener('input',()=>{settingsChanged=true;draw();});$(id).addEventListener('pointerdown',()=>editing=true);['pointerup','change','touchend'].forEach(ev=>$(id).addEventListener(ev,()=>editing=false));});
$('ad').addEventListener('change',()=>settingsChanged=true);
$('i').addEventListener('input',draw);
$('i').addEventListener('change',async()=>{try{const r=await fetch('/api/current',{method:'POST',headers:{'Content-Type':'text/plain'},body:$('i').value});const j=await r.json();$('msg').textContent=j.ok?'Simulated current saved to ESP32.':'Could not save current: '+j.error;}catch(e){$('msg').textContent='Could not save simulated current';}});
async function setManual(on){try{const r=await fetch('/api/manual',{method:'POST',headers:{'Content-Type':'text/plain'},body:on?'1':'0'});const j=await r.json();if(!j.ok)throw Error(j.error);$('manualMsg').textContent=on?'Manual trip activated. Reset is required.':'Manual request OFF. Trip remains latched until Reset.';await loadState();}catch(e){$('manualMsg').textContent='Manual trip request failed: '+e.message;}}
$('manual').addEventListener('change',()=>setManual($('manual').checked));
async function resetSystem(){try{const r=await fetch('/api/reset',{method:'POST'});const j=await r.json();$('manualMsg').textContent=j.ok?'Protection reset.':'Reset blocked: '+j.error;await loadState();}catch(e){$('manualMsg').textContent='Reset request failed';}}
async function loadState(){try{const r=await fetch('/api/state');const d=await r.json();if(!settingsChanged&&!editing){$('oc').value=d.oc;$('uc').value=d.uc;$('ad').checked=d.adaptive;}$('i').value=d.demo;$('manual').checked=d.manual;draw();$('v').textContent=d.voltageValid?d.voltage+' V':'INVALID';$('demoNow').textContent=d.demo+' A';$('raw').textContent=d.acsRaw;$('acs').textContent=d.acsValid?d.acsEstimate+' A (est.)':'unavailable';$('relay').textContent=d.relay?'ENABLED':'DISABLED';$('state').textContent=d.state;$('effective').textContent='Effective limits: OC '+d.effectiveOc+' A | UC '+d.effectiveUc+' A';$('status').textContent='Trip reason: '+d.tripReason+' | Voltage input: '+(d.voltageValid?'valid':'invalid')+' | Manual trip: '+(d.manual?'ON':'OFF');$('last').textContent='Last logged event: '+d.last;}catch(e){$('status').textContent='Connection error';}}
async function saveSettings(){const d={oc:+$('oc').value,uc:+$('uc').value,adaptive:$('ad').checked};if(d.uc>=d.oc){$('msg').textContent='UC must be lower than OC';return;}try{const r=await fetch('/api/settings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(d)});const j=await r.json();if(j.ok){settingsChanged=false;$('msg').textContent='Protection settings saved';await loadState();}else $('msg').textContent='Error: '+j.error;}catch(e){$('msg').textContent='Save failed';}}
draw();loadState();setInterval(loadState,1200);
</script></body></html>)HTML";

static const char* stateName(SystemState state) {
  switch (state) {
    case SystemState::HEALTHY: return "HEALTHY";
    case SystemState::WARNING: return "WARNING";
    case SystemState::TRIPPED: return "TRIPPED";
    case SystemState::SENSOR_ERROR: return "INPUT ERROR";
    default: return "STARTUP";
  }
}

static String faultName(uint8_t faults) {
  if (faults == FAULT_NONE) return "None";
  String s;
  if (faults & FAULT_MANUAL) s += "MANUAL TRIP, ";
  if (faults & FAULT_OV) s += "OV, ";
  if (faults & FAULT_UV) s += "UV, ";
  if (faults & FAULT_OC) s += "OC, ";
  if (faults & FAULT_UC) s += "UC, ";
  if (faults & FAULT_INPUT) s += "INPUT INVALID, ";
  if (s.endsWith(", ")) s.remove(s.length()-2);
  return s;
}
static String jsonSafe(String value) {
  value.replace("\\", "\\\\"); value.replace("\"", "\\\"");
  value.replace("\n", " "); value.replace("\r", " ");
  return value;
}

void LocalWebServer::begin(ProtectionSettings* settings, CurrentSimulator* simulator,
                           FaultLogger* log, SettingsStore* settingsStore,
                           Protection* protection) {
  _settings=settings; _simulator=simulator; _log=log;
  _settingsStore=settingsStore; _protection=protection;
  WiFi.mode(WIFI_AP);
  WiFi.softAP(AIDPR_AP_SSID, AIDPR_AP_PASSWORD);
  _server.on("/", HTTP_GET, [this]() { _server.send_P(200,"text/html",PAGE); });
  _server.on("/api/state", HTTP_GET, [this]() { sendState(); });

  _server.on("/api/current", HTTP_POST, [this]() {
    if (!_simulator || !_settingsStore) { _server.send(500,"application/json","{\"ok\":false,\"error\":\"Storage unavailable\"}"); return; }
    String raw=_server.arg("plain");
    if (!raw.length()) { _server.send(400,"application/json","{\"ok\":false,\"error\":\"Missing current value\"}"); return; }
    float amps=raw.toFloat();
    if (!isfinite(amps) || amps<0.0f || amps>5.0f) { _server.send(400,"application/json","{\"ok\":false,\"error\":\"Current must be 0 to 5 A\"}"); return; }
    _simulator->set(amps); _settingsStore->saveDemoCurrent(amps);
    _server.send(200,"application/json","{\"ok\":true}");
  });

  _server.on("/api/settings", HTTP_POST, [this]() {
    if (!_settings || !_settingsStore) { _server.send(500,"application/json","{\"ok\":false,\"error\":\"Settings unavailable\"}"); return; }
    String body=_server.arg("plain");
    int ocPos=body.indexOf("\"oc\""); int ucPos=body.indexOf("\"uc\""); int adPos=body.indexOf("\"adaptive\"");
    if (ocPos<0 || ucPos<0 || adPos<0) { _server.send(400,"application/json","{\"ok\":false,\"error\":\"Missing fields\"}"); return; }
    float oc=body.substring(body.indexOf(':',ocPos)+1).toFloat();
    float uc=body.substring(body.indexOf(':',ucPos)+1).toFloat();
    bool adaptive=body.substring(body.indexOf(':',adPos)+1).startsWith("true");
    if (!isfinite(oc)||!isfinite(uc)||oc<0.1f||oc>5.0f||uc<0.0f||uc>2.0f||uc>=oc) { _server.send(400,"application/json","{\"ok\":false,\"error\":\"Invalid thresholds\"}"); return; }
    _settings->oc=oc; _settings->uc=uc; _settings->adaptive=adaptive;
    _settingsStore->save(*_settings);
    _server.send(200,"application/json","{\"ok\":true}");
  });

  _server.on("/api/manual", HTTP_POST, [this]() {
    String value=_server.arg("plain");
    _manualTrip=(value=="1" || value=="true" || value=="on");
    if (_manualTrip && _protection) _protection->trip(FAULT_MANUAL);
    _server.send(200,"application/json","{\"ok\":true}");
  });

  _server.on("/api/reset", HTTP_POST, [this]() {
    if (_manualTrip) { _server.send(409,"application/json","{\"ok\":false,\"error\":\"Turn manual trip OFF first\"}"); return; }
    if (!_protection || !_protection->reset()) { _server.send(409,"application/json","{\"ok\":false,\"error\":\"Trip is latched or an automatic fault/input is still active\"}"); return; }
    _server.send(200,"application/json","{\"ok\":true}");
  });
  _server.begin();
}

void LocalWebServer::updateTelemetry(float voltage, bool voltageValid,
                                     const Protection& protection, bool relayEnabled,
                                     const CurrentReading& acsReading,
                                     float effectiveOc, float effectiveUc) {
  _voltage=voltage; _voltageValid=voltageValid; _state=protection.state();
  _relayEnabled=relayEnabled; _acsReading=acsReading;
  _effectiveOc=effectiveOc; _effectiveUc=effectiveUc;
}

void LocalWebServer::sendState() {
  if (!_settings||!_simulator||!_log||!_protection) { _server.send(500,"application/json","{\"error\":\"Status unavailable\"}"); return; }
  String reason = _state==SystemState::TRIPPED ? faultName(_protection->faults()) :
                  (_state==SystemState::SENSOR_ERROR ? "Invalid protection input" : "None");
  String response="{\"oc\":"+String(_settings->oc,1)+
    ",\"uc\":"+String(_settings->uc,1)+
    ",\"adaptive\":"+String(_settings->adaptive?"true":"false")+
    ",\"demo\":"+String(_simulator->value(),2)+
    ",\"voltage\":"+String(_voltage,1)+
    ",\"voltageValid\":"+String(_voltageValid?"true":"false")+
    ",\"acsRaw\":"+String(_acsReading.rawAdc)+
    ",\"acsEstimate\":"+String(_acsReading.rmsAmps,2)+
    ",\"acsValid\":"+String(_acsReading.valid?"true":"false")+
    ",\"effectiveOc\":"+String(_effectiveOc,2)+
    ",\"effectiveUc\":"+String(_effectiveUc,2)+
    ",\"manual\":"+String(_manualTrip?"true":"false")+
    ",\"state\":\""+String(stateName(_state))+"\""+
    ",\"relay\":"+String(_relayEnabled?"true":"false")+
    ",\"tripReason\":\""+jsonSafe(reason)+"\""+
    ",\"last\":\""+jsonSafe(_log->last())+"\"}";
  _server.send(200,"application/json",response);
}
void LocalWebServer::handle() { _server.handleClient(); }
