#pragma once
#include <Arduino.h>
#include <WebServer.h>
#include "../protection/protection.h"
#include "../simulation/current_simulator.h"
#include "../storage/fault_logger.h"
#include "../storage/settings.h"
#include "../sensors/current_sensor.h"

class LocalWebServer {
public:
  void begin(ProtectionSettings* settings, CurrentSimulator* simulator,
             FaultLogger* log, SettingsStore* settingsStore, Protection* protection);
  void updateTelemetry(float voltage, bool voltageValid, const Protection& protection,
                       bool relayEnabled, const CurrentReading& acsReading,
                       float effectiveOc, float effectiveUc);
  void handle();
  bool manualTripActive() const { return _manualTrip; }
private:
  WebServer _server{80};
  ProtectionSettings* _settings = nullptr;
  CurrentSimulator* _simulator = nullptr;
  FaultLogger* _log = nullptr;
  SettingsStore* _settingsStore = nullptr;
  Protection* _protection = nullptr;
  float _voltage = 0.0f;
  float _effectiveOc = 0.0f, _effectiveUc = 0.0f;
  bool _voltageValid = false, _relayEnabled = false, _manualTrip = false;
  SystemState _state = SystemState::STARTUP;
  CurrentReading _acsReading;
  void sendState();
};
