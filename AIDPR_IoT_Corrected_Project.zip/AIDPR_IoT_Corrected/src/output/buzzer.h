#pragma once
#include <Arduino.h>
class Buzzer {public:void begin(uint8_t pin);void set(bool on);private:uint8_t _pin;};
