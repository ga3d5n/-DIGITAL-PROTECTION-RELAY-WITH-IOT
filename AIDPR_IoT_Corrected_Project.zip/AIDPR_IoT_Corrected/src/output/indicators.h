#pragma once
#include <Arduino.h>
class Indicators { public:void begin(uint8_t g,uint8_t y,uint8_t r);void update(bool healthy,bool warning,bool tripped);private:uint8_t _g,_y,_r; };
