#include "indicators.h"
void Indicators::begin(uint8_t g,uint8_t y,uint8_t r){_g=g;_y=y;_r=r;pinMode(_g,OUTPUT);pinMode(_y,OUTPUT);pinMode(_r,OUTPUT);update(false,false,false);}
void Indicators::update(bool healthy,bool warning,bool tripped){digitalWrite(_g,healthy?HIGH:LOW);digitalWrite(_y,warning?HIGH:LOW);digitalWrite(_r,tripped?HIGH:LOW);}
