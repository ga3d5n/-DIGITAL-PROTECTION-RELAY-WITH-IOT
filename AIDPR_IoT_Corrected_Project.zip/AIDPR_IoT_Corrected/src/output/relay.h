#pragma once
#include <Arduino.h>
class RelayOutput { public: void begin(uint8_t pin,bool activeLow); void setLoad(bool enabled); bool loadEnabled()const{return _enabled;} private:uint8_t _pin;bool _activeLow,_enabled=false; };
