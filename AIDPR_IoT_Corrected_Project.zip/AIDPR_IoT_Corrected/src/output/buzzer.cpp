#include "buzzer.h"
void Buzzer::begin(uint8_t pin){_pin=pin;pinMode(_pin,OUTPUT);set(false);}
void Buzzer::set(bool on){digitalWrite(_pin,on?HIGH:LOW);}
