#include "relay.h"
void RelayOutput::begin(uint8_t pin,bool activeLow){_pin=pin;_activeLow=activeLow;pinMode(_pin,OUTPUT);setLoad(false);}
void RelayOutput::setLoad(bool enabled){_enabled=enabled;digitalWrite(_pin,enabled?(_activeLow?LOW:HIGH):(_activeLow?HIGH:LOW));}
