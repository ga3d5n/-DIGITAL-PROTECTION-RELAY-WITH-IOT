#include "oled.h"
#include "../../config.h"
#include <Wire.h>

bool OledDisplay::begin() {
  Wire.begin(Pins::OLED_SDA, Pins::OLED_SCL);
  return _display.begin(SSD1306_SWITCHCAPVCC, Config::OLED_ADDRESS);
}

void OledDisplay::update(float volts, bool voltageOK, float simulatedAmps,
                         const ProtectionSettings& limits, const Protection& protection,
                         const CurrentReading& acsReading) {
  _display.clearDisplay();
  _display.setTextColor(SSD1306_WHITE);
  _display.setTextSize(1);
  _display.setCursor(0, 0);
  _display.println("AIDPR-IoT");
  _display.print("V: ");
  if (voltageOK) { _display.print(volts, 1); _display.println(" V"); }
  else _display.println("INVALID");
  _display.print("SIM I: "); _display.print(simulatedAmps, 2); _display.println(" A");
  _display.print("OC:"); _display.print(limits.oc, 1);
  _display.print(" UC:"); _display.print(limits.uc, 1); _display.println(" A");
  _display.print("ACS raw:"); _display.print(acsReading.rawAdc);
  _display.print(" I~:");
  if (acsReading.valid) _display.print(acsReading.rmsAmps, 1);
  else _display.print("--");
  _display.println("A");
  _display.print("STATE: ");
  switch (protection.state()) {
    case SystemState::HEALTHY: _display.println("HEALTHY"); break;
    case SystemState::WARNING: _display.println("WARNING"); break;
    case SystemState::TRIPPED: _display.println("TRIPPED"); break;
    case SystemState::SENSOR_ERROR: _display.println("INPUT ERROR"); break;
    default: _display.println("STARTUP"); break;
  }
  _display.display();
}
