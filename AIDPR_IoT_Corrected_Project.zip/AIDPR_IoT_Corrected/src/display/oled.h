#pragma once
#include <Arduino.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "../protection/protection.h"
#include "../sensors/current_sensor.h"

class OledDisplay {
public:
  bool begin();
  void update(float volts, bool voltageOK, float simulatedAmps,
              const ProtectionSettings& limits, const Protection& protection,
              const CurrentReading& acsReading);
private:
  Adafruit_SSD1306 _display{128, 64, &Wire, -1};
};
