#include "current_sensor.h"
#include "../../config.h"

void CurrentSensor::begin(uint8_t pin) {
  _pin = pin;
  pinMode(_pin, INPUT);
  double sum = 0.0;
  for (int i = 0; i < 300; ++i) {
    sum += analogReadMilliVolts(_pin) / 1000.0;
    delay(2);
  }
  _zeroAdcVolts = (float)(sum / 300.0);
}

CurrentReading CurrentSensor::readRms(uint32_t windowMs) {
  const uint32_t start = millis();
  uint32_t n = 0;
  uint32_t rawSum = 0;
  double sum = 0.0, sumSq = 0.0;
  while (millis() - start < windowMs) {
    const int raw = analogRead(_pin);
    const float volts = analogReadMilliVolts(_pin) / 1000.0f;
    const float ac = volts - _zeroAdcVolts;
    rawSum += (uint32_t)raw;
    sum += ac;
    sumSq += (double)ac * ac;
    ++n;
    delayMicroseconds(250);
  }

  CurrentReading out;
  if (n < 100) return out;
  out.rawAdc = (uint16_t)(rawSum / n);
  const float adcRms = sqrt(max(0.0f, (float)(sumSq / n - (sum / n) * (sum / n))));
  const float sensorRms = adcRms * Config::ADC_DIVIDER_RATIO;
  out.outputVolts = _zeroAdcVolts * Config::ADC_DIVIDER_RATIO;
  out.rmsAmps = sensorRms / Config::ACS712_SENSITIVITY_V_PER_A;
  // Experimental display estimate only. It is intentionally not a protection input.
  out.valid = isfinite(out.rmsAmps) && out.rmsAmps < 35.0f;
  return out;
}
