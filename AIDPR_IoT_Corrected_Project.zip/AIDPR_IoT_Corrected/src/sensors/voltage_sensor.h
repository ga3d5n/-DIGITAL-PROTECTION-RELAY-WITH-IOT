#pragma once
#include <Arduino.h>
struct VoltageReading { float rmsVolts=0; bool valid=false; };
class VoltageSensor {
public:
  void begin(uint8_t pin);
  VoltageReading readRms(uint32_t windowMs);
private:
  uint8_t _pin=34;
};
