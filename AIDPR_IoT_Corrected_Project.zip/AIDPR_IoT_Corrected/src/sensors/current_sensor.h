#pragma once
#include <Arduino.h>

struct CurrentReading {
  uint16_t rawAdc = 0;
  float outputVolts = 0.0f;
  float rmsAmps = 0.0f;
  bool valid = false;
};

class CurrentSensor {
public:
  void begin(uint8_t pin);
  CurrentReading readRms(uint32_t windowMs);
private:
  uint8_t _pin = 35;
  float _zeroAdcVolts = 1.25f;
};
