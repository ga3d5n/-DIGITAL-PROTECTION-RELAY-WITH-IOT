#include "voltage_sensor.h"
#include "../../config.h"
void VoltageSensor::begin(uint8_t pin) { _pin=pin; pinMode(_pin, INPUT); }
VoltageReading VoltageSensor::readRms(uint32_t windowMs) {
  // AC-coupled/bias-centred waveform sampling. Validate the complete waveform
  // at the ADC pin first; this software cannot make an unsafe signal safe.
  const uint32_t start=millis();
  double sum=0, sumSq=0; uint32_t n=0;
  while (millis()-start < windowMs) {
    float v=analogReadMilliVolts(_pin)/1000.0f;
    sum += v; sumSq += (double)v*v; ++n;
    delayMicroseconds(250); // ~4 ksample/s nominal; validate timing on target
  }
  VoltageReading out;
  if (n < 100) return out;
  double mean=sum/n;
  double variance=(sumSq/n)-(mean*mean);
  if (variance < 0) variance=0;
  float sensorVrms=sqrt((float)variance) * Config::ADC_DIVIDER_RATIO;
  out.rmsVolts=sensorVrms*Config::ZMPT_VOLTS_PER_SENSOR_VOLT;
  out.valid=isfinite(out.rmsVolts) && out.rmsVolts > 20.0f && out.rmsVolts < 300.0f;
  return out;
}
